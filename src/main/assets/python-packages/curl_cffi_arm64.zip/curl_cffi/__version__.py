# Patched for yt-dlp compatibility on Android.
# Reports 0.14.0 to pass yt-dlp's version gate while actually being 0.15.0.

__curl_version__ = "8.13.0"
__description__ = "libcurl ffi bindings for Python"
__title__ = "curl_cffi"
__version__ = "0.14.0"
